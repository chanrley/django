
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from notebook import *
from . import views

app_name = 'notebook'

urlpatterns = [
    path('', views.index, name='index'),
    path('main/', views.main, name='main'),

]  + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT )
