from django.shortcuts import render
from django.utils import timezone
from .models import Member

def index(request):
    ano_atual = timezone.now().year
    contexto = { 'ano_atual': ano_atual }
    return render(request, 'notebook/index.html', contexto)

def main(request):

    members = Member.objects.all()


    contexto = {
        'titulo': 'LangDex Notebook',
        'descricao': 'Um caderno de anotações para o LangDex',
        'ano_atual': timezone.now().year,
        'members': members,
    }
    return render(request, 'notebook/main.html', contexto)