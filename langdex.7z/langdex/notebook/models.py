from django.db import models

# Create your models here.
class Member(models.Model):
    code = models.CharField(max_length=4)
    name = models.CharField(max_length=100)
    category1 = models.CharField(max_length=10)
    category2 = models.CharField(max_length=10)
    photo = models.ImageField(upload_to='member_photos/')

    def __str__(self):
        return f"{self.code} - {self.name}"