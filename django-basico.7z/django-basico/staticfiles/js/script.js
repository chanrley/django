function teste(){
    alert("Funciona msm!")
}

