from logging import CRITICAL, ERROR, WARNING, INFO, DEBUG
# DEBUB Somente em dev
from logging import basicConfig
from logging import critical, error, warning, info, debug
from logging import FileHandler, StreamHandler, Filter

class Filtro(Filter):
    def filter(self, record):
        if 'cartao' in record.msg:
            record.msg = "Vazou a senha do cartao"
            return True
        return True



file_handler = FileHandler('logs.log', 'a')
file_handler.setLevel(WARNING)
file_handler.addFilter(Filtro())
stream_handler = StreamHandler()


basicConfig(
    level=DEBUG,
    # filename='logs.log',
    # filemode='a',
    format='%(levelname)s:%(asctime)s:%(message)s',
    handlers=[file_handler, stream_handler]
)

debug('Estou testando')
critical('Senha do usuário foi exposta')

try:
    x = int(input('Digite um número!'))
    y = 10/x

except ZeroDivisionError:
    warning("Tentou dividir por zero")

warning('ops deu erro cartao 12345')
warning('deu warning')


