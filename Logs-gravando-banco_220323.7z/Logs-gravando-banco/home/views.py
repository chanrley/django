from django.shortcuts import render
from django.http import HttpResponse
import logging

logger = logging.getLogger('django')
db_logger = logging.getLogger('db')


def home(request):
    #request.user != AnonymousUser
    print(request)
    logger.info('Deu INFO por aqui')

    db_logger.info('INFo 3333')
    db_logger.warning('WARNING 3333')
    return HttpResponse('333')
