from django.test import TestCase
import logging


db_logger = logging.getLogger('db')

db_logger.info('INFOOO')
db_logger.warning('WARNING')

try:
    1/0
except Exception as e:
    db_logger.exception(e)


